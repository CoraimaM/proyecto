CREATE DATABASE  IF NOT EXISTS `proyecto` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `proyecto`;
-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: proyecto
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clientes_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'D. Miguel Ángel Esquibel','leire69@example.com','673-856-914','Calle Mayor, 338, Sevilla','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(2,'Dr. Francisco Javier Rubio Tercero','tclemente@example.com','678-042-763','Calle Real, 142, Palma','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(3,'Ander Delarosa Hijo','ordonez.amparo@example.com','616-593-687','Pasaje Comercial, 406, Málaga','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(4,'Joel Padrón','gloria.perales@example.com','683-191-527','Calle Mayor, 141, Alicante','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(5,'Lic. Juana Torres','diana02@example.com','603-906-853','Paseo del Prado, 459, Alicante','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(6,'Yago Ocasio','gael78@example.net','623-874-802','Pasaje Comercial, 138, Bilbao','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(7,'Jesús Castillo','ian.sanz@example.net','640-559-492','Calle Mayor, 64, Alicante','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(8,'Ing. Alberto Robledo','rcarbajal@example.net','618-090-660','Avenida Central, 400, Valencia','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(9,'Carla Meza','leire.cortes@example.org','632-793-746','Pasaje Comercial, 206, Murcia','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(10,'Eric Torres','egamez@example.com','619-414-605','Avenida Central, 33, Alicante','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(11,'Mateo Tello','carlota02@example.org','641-118-468','Avenida Principal, 354, Valencia','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(12,'Diana Chapa','harevalo@example.org','677-585-492','Calle Mayor, 267, Bilbao','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(13,'Ing. Samuel Corona','margarita.villalobos@example.net','674-892-066','Avenida Principal, 307, Madrid','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(14,'Lic. Biel Córdova Segundo','miramontes.miriam@example.com','611-584-485','Calle Mayor, 116, Bilbao','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(15,'Dña Ana María Gallegos Hijo','furrutia@example.com','630-574-242','Avenida Principal, 45, Madrid','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(16,'Daniel Blasco Hijo','contreras.juan@example.net','687-949-562','Avenida Principal, 232, Valencia','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(17,'Encarnación Salinas','pol.fonseca@example.net','648-486-811','Calle Real, 79, Valencia','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(18,'Alonso Escamilla','zruiz@example.org','685-864-224','Paseo del Prado, 392, Palma','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(19,'D. Santiago Lorente Tercero','jan77@example.org','628-707-254','Calle Mayor, 496, Bilbao','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(20,'Aaron Aguado','aitor.conde@example.com','618-600-687','Avenida Principal, 334, Bilbao','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(21,'Emilia Hernández','marc.villar@example.net','645-497-811','Pasaje Comercial, 53, Málaga','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(22,'Gabriela Pabón','rosario.calderon@example.net','631-303-654','Avenida Principal, 59, Valencia','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(23,'Arnau Carmona Hijo','duarte.raul@example.com','663-639-490','Paseo del Prado, 367, Bilbao','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(24,'Antonia Elizondo','saez.javier@example.com','640-799-777','Avenida Principal, 233, Murcia','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(25,'David Monroy','erik80@example.net','660-199-571','Calle Mayor, 486, Las Palmas','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(26,'Luis Arroyo','blanca02@example.org','630-858-449','Pasaje Comercial, 176, Málaga','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(27,'Dña Berta Yáñez Segundo','diez.luna@example.net','653-924-536','Avenida Principal, 306, Murcia','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(28,'Lic. Carlos Lucero','emadrigal@example.net','652-235-823','Calle Real, 170, Bilbao','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(29,'Manuela Alvarado','apadron@example.net','677-236-422','Paseo del Prado, 251, Sevilla','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(30,'Naia Terán','bpastor@example.net','699-712-828','Avenida Central, 314, Palma','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleados`
--

DROP TABLE IF EXISTS `empleados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleados` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `puesto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `departamento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salario` decimal(10,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `empleados_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleados`
--

LOCK TABLES `empleados` WRITE;
/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
INSERT INTO `empleados` VALUES (1,'Ángel Báez','pablo.alcantar@padron.org','+34 926 82 4373','Community Manager','IT',37595.82,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(2,'Diego Curiel','martinez.aaron@gonzales.com','+34 985745960','Director de Diseño','Marketing',72273.06,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(3,'Miriam Mesa','moran.sofia@garcia.net','964-61-4971','Diseñador Gráfico Junior','Marketing',28082.96,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(4,'Roberto Montes Hijo','vcolunga@barela.es','998-714749','Especialista en Marketing Digital','Diseño',49483.62,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(5,'Verónica Lorenzo','anamaria.armenta@montano.com.es','+34 948 725307','Diseñador Gráfico Senior','RRHH',40629.10,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(6,'Lic. Ana Paredes','loya.daniel@alcaraz.net','+34 922 57 4112','Community Manager','IT',49198.34,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(7,'Dr. Oriol Vargas','alba.giron@zavala.es','+34 901-823711','Director de Diseño','IT',44693.33,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(8,'Inés Alcaráz Segundo','alarcon.daniel@gastelum.es','973-102865','Community Manager','Marketing',42656.77,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(9,'Saúl Suárez','rosamaria94@yahoo.com','964428833','Asistente Administrativo','RRHH',49715.72,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(10,'Antonio Alicea Tercero','marco90@avalos.com','996941087','Especialista en Marketing Digital','Diseño',45516.37,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(11,'Ing. Raquel Del Río','pozo.luis@orozco.com','996 65 2475','Ejecutivo de Cuentas','IT',58700.25,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(12,'Alex Domenech','vila.oliver@castellano.org','+34 955214715','Asistente Administrativo','Ventas',65185.85,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL);
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facturas`
--

DROP TABLE IF EXISTS `facturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facturas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cliente_id` bigint unsigned DEFAULT NULL,
  `monto` decimal(12,2) NOT NULL,
  `fecha` date NOT NULL,
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `notas` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `facturas_numero_unique` (`numero`),
  KEY `facturas_cliente_id_foreign` (`cliente_id`),
  CONSTRAINT `facturas_cliente_id_foreign` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facturas`
--

LOCK TABLES `facturas` WRITE;
/*!40000 ALTER TABLE `facturas` DISABLE KEYS */;
INSERT INTO `facturas` VALUES (1,'FAC-607110',10,593.27,'2026-01-15','pagada',NULL,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(2,'FAC-357187',24,3694.12,'2025-12-04','pagada','Proyecto especial con descuento','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(3,'FAC-396939',3,6499.31,'2025-11-07','pendiente','Factura rectificativa','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(4,'FAC-106304',15,229.07,'2025-11-09','pendiente','Pago por adelantado','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(5,'FAC-773349',14,8208.40,'2025-11-07','pendiente',NULL,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(6,'FAC-121128',11,2459.86,'2026-01-06','pagada','Pago por adelantado','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(7,'FAC-986268',26,354.55,'2025-10-30','pagada',NULL,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(8,'FAC-138390',15,424.82,'2025-12-05','pagada',NULL,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(9,'FAC-757449',3,4662.88,'2025-12-23','pendiente',NULL,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(10,'FAC-298548',6,9045.25,'2025-11-11','pagada',NULL,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(11,'FAC-019275',25,8897.36,'2026-01-20','pendiente','Proyecto completado','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(12,'FAC-077987',3,7058.50,'2025-11-27','pendiente',NULL,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(13,'FAC-147393',9,6764.07,'2025-11-24','pagada','Servicio premium','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(14,'FAC-823640',24,2334.67,'2025-12-07','pendiente','Entrega en tiempo','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(15,'FAC-230443',20,2175.48,'2025-12-27','pendiente','Pago por adelantado','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(16,'FAC-608740',22,4116.32,'2025-11-28','pendiente',NULL,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(17,'FAC-964510',26,8494.95,'2025-11-17','pagada',NULL,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(18,'FAC-456584',11,3941.21,'2025-12-25','pendiente','Entrega en tiempo','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(19,'FAC-031209',15,452.00,'2025-11-14','pagada','Incluye soporte técnico','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(20,'FAC-796502',11,8372.43,'2025-12-26','pendiente','Pago a 30 días','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL);
/*!40000 ALTER TABLE `facturas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incidencias`
--

DROP TABLE IF EXISTS `incidencias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incidencias` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `estado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'abierta',
  `prioridad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `usuario_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `incidencias_usuario_id_foreign` (`usuario_id`),
  CONSTRAINT `incidencias_usuario_id_foreign` FOREIGN KEY (`usuario_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incidencias`
--

LOCK TABLES `incidencias` WRITE;
/*!40000 ALTER TABLE `incidencias` DISABLE KEYS */;
INSERT INTO `incidencias` VALUES (1,'Solicitud de información','El cliente solicita cambios en el diseño presentado','cerrada','normal',2,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(2,'Error de comunicación','Problema técnico en la entrega del archivo','abierta','normal',6,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(3,'Incidencia técnica','El cliente solicita cambios en el diseño presentado','pendiente','alta',2,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(4,'Ajuste de tipografía','Retraso en la entrega por falta de recursos','abierta','baja',5,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(5,'Problema con paleta de colores','Retraso en la entrega por falta de recursos','pendiente','baja',3,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(6,'Revisión de banners web','Falta información para continuar','pendiente','alta',3,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(7,'Ajuste de tipografía','Retraso en la entrega por falta de recursos','pendiente','alta',4,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(8,'Incidencia técnica','Necesita revisión de cumplimiento','abierta','alta',4,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(9,'Retraso en entrega','Es necesario revisar la calidad del trabajo','cerrada','baja',4,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(10,'Problema con paleta de colores','El cliente solicita cambios en el diseño presentado','pendiente','alta',2,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(11,'Ajuste de tipografía','Retraso en la entrega por falta de recursos','cerrada','normal',1,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(12,'Incidencia técnica','Cambio de requisitos del proyecto','cerrada','normal',1,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(13,'Problema con cliente','Problema técnico en la entrega del archivo','cerrada','alta',3,'2026-01-29 18:02:23','2026-01-29 18:29:27','2026-01-29 18:29:27'),(14,'Solicitud de información','Retraso en la entrega por falta de recursos','cerrada','normal',2,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(15,'Problema con cliente','Se requiere aprobación del gerente','abierta','baja',3,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(16,'Retraso en entrega','Es necesario revisar la calidad del trabajo','abierta','normal',5,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(17,'Retraso en entrega','Cambio de requisitos del proyecto','cerrada','baja',3,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(18,'Error de facturación','Problema técnico en la entrega del archivo','cerrada','alta',6,'2026-01-29 18:02:23','2026-01-29 18:02:23',NULL);
/*!40000 ALTER TABLE `incidencias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (77,'0001_01_01_000000_create_users_table',1),(78,'0001_01_01_000001_create_cache_table',1),(79,'0001_01_01_000002_create_jobs_table',1),(80,'2026_01_29_000000_add_deleted_at_to_clientes_table',1),(81,'2026_01_29_010000_create_clientes_table_if_not_exists',1),(82,'2026_01_29_182857_create_productos_table',1),(83,'2026_01_29_182857_create_proveedors_table',1),(84,'2026_01_29_182858_create_empleados_table',1),(85,'2026_01_29_182858_create_facturas_table',1),(86,'2026_01_29_182858_create_incidencias_table',1),(87,'2026_01_29_183805_create_views',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `precio` decimal(10,2) NOT NULL,
  `stock` int NOT NULL DEFAULT '0',
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `productos_sku_unique` (`sku`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,'Tarjetas de Presentación','Diseño de tarjetas de presentación personalizadas',218.51,14,'DG-5245-lv','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(2,'Kit de Iconos','Conjunto de iconos personalizados para tu proyecto',520.31,31,'DG-1661-ty','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(3,'Banner Web','Banners optimizados para sitios web y redes sociales',345.73,49,'DG-3589-az','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(4,'Portada de Libro','Diseño de portada para libros y ebooks',636.91,39,'DG-6991-bh','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(5,'Plantilla Powerpoint','Plantillas profesionales para presentaciones',210.84,26,'DG-1513-ns','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(6,'Branding Completo','Paquete completo de identidad visual: logo, paleta, tipografía',987.30,42,'DG-3558-xq','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(7,'Diseño de Packaging','Diseño de empaque y etiquetado para productos',521.17,39,'DG-0117-kj','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(8,'Portada de Libro','Diseño de portada para libros y ebooks',367.90,49,'DG-0360-wu','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(9,'Etiquetas y Pegatinas','Diseño de etiquetas y pegatinas para productos',177.16,37,'DG-1309-tr','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(10,'Kit de Iconos','Conjunto de iconos personalizados para tu proyecto',957.78,47,'DG-6856-ie','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(11,'Infografía','Infografía custom basada en tus datos',364.22,33,'DG-6164-qb','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(12,'Diseño de Revista','Diseño de páginas interiores y portada de revista',1977.28,31,'DG-9240-xq','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(13,'Plantilla Powerpoint','Plantillas profesionales para presentaciones',337.07,27,'DG-2223-kl','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(14,'Diseño de Menú','Menú restaurante o cafetería con diseño gráfico profesional',157.65,19,'DG-4184-py','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(15,'Póster Artístico','Póster decorativo personalizado para imprenta',250.67,1,'DG-8862-js','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL);
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedors`
--

DROP TABLE IF EXISTS `proveedors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` text COLLATE utf8mb4_unicode_ci,
  `empresa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `proveedors_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedors`
--

LOCK TABLES `proveedors` WRITE;
/*!40000 ALTER TABLE `proveedors` DISABLE KEYS */;
INSERT INTO `proveedors` VALUES (1,'Shutterstock','montes.ariadna@barrientos.com','681-132-089','Avenida Central, 368, Alicante','Banco de imágenes y recursos gráficos','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(2,'Creative Market','nerea70@rosario.org','670-343-110','Paseo del Prado, 458, Alicante','Marketplace de recursos de diseño','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(3,'Getty Images','clara.pelayo@laureano.com','699-893-051','Calle Real, 94, Murcia','Base de datos de fotografías de alta calidad','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(4,'123Royalty Free','carlos81@navas.es','696-790-247','Calle Mayor, 103, Las Palmas','Música y sonidos para proyectos','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(5,'Istock Photos','valentina47@velez.com','612-825-310','Paseo del Prado, 144, Palma','Banco de stock photography','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(6,'Adobe Creative Cloud','azavala@nava.org','674-955-662','Pasaje Comercial, 349, Madrid','Proveedor de software de diseño profesional','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(7,'Canva Pro','veronica94@lazaro.es','686-270-153','Calle Mayor, 105, Alicante','Plataforma de diseño simplificada','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(8,'Creative Market','jaime.meraz@quesada.com','619-764-973','Pasaje Comercial, 2, Alicante','Marketplace de recursos de diseño','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(9,'Creative Market','emilia.feliciano@jaramillo.org','624-337-039','Calle Real, 175, Bilbao','Marketplace de recursos de diseño','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL),(10,'Shutterstock','hernadez.anaisabel@gonzales.com.es','681-353-118','Avenida Central, 19, Barcelona','Banco de imágenes y recursos gráficos','2026-01-29 18:02:23','2026-01-29 18:02:23',NULL);
/*!40000 ALTER TABLE `proveedors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('DhRarDwMSiKEhpE1EOIH2JAKDZ3trhhRE6lCEy9A',6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','YTo2OntzOjY6Il90b2tlbiI7czo0MDoidkNlMEVtNUJackdBOW1LT1ZodzNNa0dEaFNLcXhiQTN5YlVFdFhBQiI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjIxOiJodHRwOi8vMTI3LjAuMC4xOjgwMDAiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjY7czo0OiJhdXRoIjthOjE6e3M6MjE6InBhc3N3b3JkX2NvbmZpcm1lZF9hdCI7aToxNzY5NzEzMzYyO319',1769714062),('XQzPQSaV1u8Uo7USx4et1xfuD5t3PXIs0HclnTy3',6,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0','YTo2OntzOjY6Il90b2tlbiI7czo0MDoiUjFxNk9QZjc2cDI4SXVPcmhOWUJHN2EyWUgwajNQSUM3VFJ2b1AyNiI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjIxOiJodHRwOi8vMTI3LjAuMC4xOjgwMDAiO3M6NToicm91dGUiO3M6NDoiaG9tZSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjY7czo0OiJhdXRoIjthOjE6e3M6MjE6InBhc3N3b3JkX2NvbmZpcm1lZF9hdCI7aToxNzY5NzE0MDgwO319',1769715933);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Ing. Javier Portillo','gabriel20@example.net','2026-01-29 18:02:22','$2y$12$K7RUz3XXbzogpXBz9KWojuA9QNYguIdwR1NYGdC/EsKgodR1J6w3y','9qFdRWvBy0','2026-01-29 18:02:23','2026-01-29 18:02:23'),(2,'Jaime Delagarza Hijo','aitana80@example.org','2026-01-29 18:02:22','$2y$12$K7RUz3XXbzogpXBz9KWojuA9QNYguIdwR1NYGdC/EsKgodR1J6w3y','RBzRJfZgKF','2026-01-29 18:02:23','2026-01-29 18:02:23'),(3,'Elena Vaca','pedraza.yaiza@example.com','2026-01-29 18:02:22','$2y$12$K7RUz3XXbzogpXBz9KWojuA9QNYguIdwR1NYGdC/EsKgodR1J6w3y','mzpv9GFRht','2026-01-29 18:02:23','2026-01-29 18:02:23'),(4,'Ángel Páez','nunez.hector@example.com','2026-01-29 18:02:23','$2y$12$K7RUz3XXbzogpXBz9KWojuA9QNYguIdwR1NYGdC/EsKgodR1J6w3y','sjffV3udEf','2026-01-29 18:02:23','2026-01-29 18:02:23'),(5,'Lara Vera','qvaca@example.org','2026-01-29 18:02:23','$2y$12$K7RUz3XXbzogpXBz9KWojuA9QNYguIdwR1NYGdC/EsKgodR1J6w3y','Fn8ugjsGzS','2026-01-29 18:02:23','2026-01-29 18:02:23'),(6,'Coraima','corimedina26@gmail.com','2026-01-29 18:02:23','$2y$12$BjKFXOjlNFf8BFq4vAgUF.SmFS/qv.SO89Rnoj2bAblkZdoM2hHvK','eVWJKxeZ8K','2026-01-29 18:02:23','2026-01-29 18:02:23');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-02 18:52:19
